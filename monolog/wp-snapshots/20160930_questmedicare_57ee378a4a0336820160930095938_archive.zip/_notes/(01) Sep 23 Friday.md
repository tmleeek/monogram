AM DG


<!--
   _____ ___  ____   ___
  |_   _/ _ \|  _ \ / _ \
    | || | | | | | | | | |
    | || |_| | |_| | |_| |
    |_| \___/|____/ \___/

-->

// 1. set up wordpress
//    - create database
//    - setup
//    - install plugins
//    - copy folder (serialize database copy)

// 2. create html files
//    - create using wp page templates

3. set up less files
//    - get fonts html
//    - less compiler


// 4. set up js files
   - place everything in default
   
   

7. create home page desktop
   - desktop header (js component)
   - desktop footer
   - 

8. create home page mobile
   - mobile header
   - mobile footer 



--------------

after lunch
 create images for mobile and desktop (all pages)
   - desktop = 150% scale, crop 4 px
   - mobile = 640px width
   - tablet (whenever applicable) = 1152px width

 create html content (all pages)
   - use default-copy
   - use different html for mobile



quest_wp











proxima nova
bold
semi-bold
regular
light


Playfair Display

black
bold
bold italic
regular
regular italic





font-family: "proxima-nova",sans-serif;
font-style: normal;
font-weight: 300;

font-family: "proxima-nova",sans-serif;
font-style: normal;
font-weight: 400;

font-family: "proxima-nova",sans-serif;
font-style: normal;
font-weight: 600;

font-family: "proxima-nova",sans-serif;
font-style: normal;
font-weight: 700;





Search


Home
Services Landing
Services Cosmetic Surgery Facilitation
Services Dentistry
Services Diabetes Treatment
Services Gastroenterology
Terms of Use
Destinations








page-home
page-services-landing
page-services-cosmetic-surgery-facilitation
page-services-dentistry
page-services-diabetes-treatment
page-services-gastroenterology
page-terms-of-use
page-destinations




Reason for contact
Salutation
First Name
Last Name
Email Address
Phone Number
Message


general enquiry
please select
enter name
enter name
enter email
enter number
please be as concise with your enquiry to allow us to assist you






contact-reason-dropdown
contact-salutation-dropdown
contact-firstname-txt
contact-lastname-txt
contact-email-txt
contact-phone-txt
contact-message-txt




First Name
Last Name
Email Address





footer-mailing-list-firstname
footer-mailing-list-lastname
footer-mailing-list-email



h5
 - playfair display regular





Contact us
Weigh your options
Medical assessment
Meeting a specialist
Preparing your trip
Arrival
Treatment
Recuperation phase
Going home
Follow up care





Any questions or clarifications you may require, we're here for you. Get in touch with us to begin your journey towards wellness and vitality.
Upon an idea of the services you require, we’ll look at your options. This includes the specialists, destinations and in-country support services and packages.
We will facilitate your medical records to your specialist and destination of your choice so that they may assess your case and recommend the right treatment for you.
We understand most patients would like to have an initial discussion with their doctors. We can facilitate this and this may be arranged via email, phone, and/or Skype.
We will take care of all the details and help you plan and prepare for everything you and your companion will need for the entirety of your trip. An information pack will be issued.
All arrangement and itinerary will be ready for you. Our friendly staff will be at their airport to pick you up on arrival and you'll be chauffeured to your accommodation or the medical centre, dependent on the tailored itinerary.
Attend a health screening and consultation meeting, we will arrange for you to be picked up from your hotel. Your treatment will be carried out subsequently upon advice following the consultation.
Recuperate in the medical centre or at your hotel of choice. Depending on the treatment and advice from your doctor, we can also arrange sightseeing tours for you after your proposed treatment.
You’ll be well rested by the time you’re ready to check out and go home, but that doesn'’t mean that your return trip should add any unwanted stress. We'll handle your transportation and your return travel plans, as well as any necessary follow-up care.
You'll be kept up to date on any follow-up necessities, be it another travel or a trip to your local doctor. We’'ll ensure that everything is taken care of and necessary follow-up care is provided.

1
2
3
4
5
6
7
8
9
10


process-item-icon-telephone
process-item-icon-three
process-item-icon-shield
process-item-icon-chat
process-item-icon-bag
process-item-icon-plane
process-item-icon-injection
process-item-icon-clock
process-item-icon-house
process-item-icon-replay


How much will I need to spend?
How long will I need to spend abroad?
Will I be travelling alone?
Will I stay in a hotel or a hospital?
What is JCI Accreditation?

You may spend more time at a hotel than at a hospital during your medical trip. Depending on your procedure, oftentimes you will only stay a night or two in the hospital and then spend the rest of the time at a hotel recuperating and/ or engaging in physical rehabilitation. So choose a hotel that has experience with medical tourists and understands your needs and expectations.














services-content-medical-concierge

services-content-banner-diabetes




services-diabetes-treatment-banner
services-diabetes-treatment-content-01
services-diabetes-treatment-content-02
services-cosmetic-surgery-facilitation-banner
services-dentistry-banner


services-gastroenterology-banner


home-banner
home-introduction-01
home-introduction-02

home-map-raster

home-services-content-01
home-services-content-02
home-services-content-03





services-cosmetic-surgery-facilitation-banner


destinations-banner
destinations-content-singapore
destinations-content-thailand
destinations-content-south-korea
destinations-content-india







home-introduction-01.jpg
home-introduction-02.jpg

home-services-content-01.jpg
home-services-content-02.jpg
home-services-content-03.jpg


home-banner.jpg
home-banner-mobile.jpg
home-banner-tablet.jpg



----------------------

things to do when you have time:

correct the layout of home process:
  - incorrect icons and the position of the numbers need to be adjusted accordingly
    font's numbers are wacked, maybe export as svg as well.








things to ask welyn
 - home faq content


http://localhost/quest-wp/
http://clients.manic.com.sg/
http://clients.manic.com.sg/quest-wp/



<!--
   _____ __  __    _    ___ _
  | ____|  \/  |  / \  |_ _| |
  |  _| | |\/| | / _ \  | || |
  | |___| |  | |/ ___ \ | || |___
  |_____|_|  |_/_/   \_\___|_____|

-->

Hi Fion,

I'm not yet done with the home page, but i created a link nevertheless. I'll explain what is not yet done

http://clients.manic.com.sg/quest-wp/

Regards,
Jairus





List of things that are missing:

1. Header 2nd level not functional
2. desktop search pop-up




Things you can check



Home page content
Mobile Home page content







// 3. click of fullscreen arrow button (scroll to next section)
// 4. what we do: as links to other pages
//   - use actual links
//   - hover states
//   - cursor pointer

// 5. map functionality
//    - data-x
//      data-y map points ?
//      vector map - 
//      map point hover states
//      - implement as fullscreen svg image

// 6. process section
//     - icons are incorrect sizes
//     - implement numbers as svg graphics
//       because the numbers of the font moves

// 7. faq expanding buttons 

8. contact us form
    - functional 'email'
    - validation states
    - stylized dropdown
    - text area (scrollbar ?)
    - thank you screen

9. subscription form
    - create temp gmail
    - create mailchimp


// 10. mobile header & 
//    header expanded state
// 11. mobile footer
// 12. mobile content (header and copy)



13. back to top button
14. desktop search (popupt)






// Desktop subscription form
// contact us form

back to top button

8. contact us form
    - functional 'email'
    - validation states
    - stylized dropdown
    - text area (scrollbar ?)
    - thank you screen

9. subscription form
    - create temp gmail
    - create mailchimp

desktop search pop out


897f74
786f65







india
771, 584

thailand
944, 562

singapore
965, 674

south korea
1142, 386




map-india
map-thailand
map-singapore
map-south-korea






things that are missing (and we cannot do anything)
1. images


D:\Localhost\quest-wp\
/clients.manic.com.sg/quest-wp


D:\Localhost\quest-wp\wp-content\themes\quest\
/clients.manic.com.sg/quest-wp/wp-content/themes/quest













<!--
   _____ __  __    _    ___ _
  | ____|  \/  |  / \  |_ _| |
  |  _| | |\/| | / _ \  | || |
  | |___| |  | |/ ___ \ | || |___
  |_____|_|  |_/_/   \_\___|_____|

-->





Hi Fion,

I have completed the home page to a certain extent, you can now check it for desktop and mobile content, but not yet for functionality.

Latest Link:
http://clients.manic.com.sg/quest-wp/

Missing functionality:

1. 'Back to Top' button
2. Desktop Subscription Form
3. Contact Us Form
4. Desktop Header Search (pop out effect like ayana)

Regards,
Jairus