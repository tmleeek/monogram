

<!--
   ____    _  _____  _    ____    _    ____  _____
  |  _ \  / \|_   _|/ \  | __ )  / \  / ___|| ____|
  | | | |/ _ \ | | / _ \ |  _ \ / _ \ \___ \|  _|
  | |_| / ___ \| |/ ___ \| |_) / ___ \ ___) | |___
  |____/_/   \_\_/_/   \_\____/_/   \_\____/|_____|

 -->


database host: localhost
database name: quest_wp
database username: root
database password: (empty field)



database host: localhost
database name: quest_wp
database username: quest_wp_user
database password: q8ues7_user!@


// for search and replace
127.0.0.1




<!--
  __        _____  ____  ____  ____  ____  _____ ____ ____
  \ \      / / _ \|  _ \|  _ \|  _ \|  _ \| ____/ ___/ ___|
   \ \ /\ / / | | | |_) | | | | |_) | |_) |  _| \___ \___ \
    \ V  V /| |_| |  _ <| |_| |  __/|  _ <| |___ ___) |__) |
     \_/\_/  \___/|_| \_\____/|_|   |_| \_\_____|____/____/

-->

url:
username: admin
password: 01qQueSSt11!




<!--
   _____ __  __    _    ___ _
  | ____|  \/  |  / \  |_ _| |
  |  _| | |\/| | / _ \  | || |
  | |___| |  | |/ ___ \ | || |___
  |_____|_|  |_/_/   \_\___|_____|

-->


username: quest.medicare.mailinglist@gmail.com
password: !qQuee5tMeedD1car3!





<!--
   __  __    _    ___ _     ____ _   _ ___ __  __ ____
  |  \/  |  / \  |_ _| |   / ___| | | |_ _|  \/  |  _ \
  | |\/| | / _ \  | || |  | |   | |_| || || |\/| | |_) |
  | |  | |/ ___ \ | || |__| |___|  _  || || |  | |  __/
  |_|  |_/_/   \_\___|_____\____|_| |_|___|_|  |_|_|

-->


username: quest.medicare.mailinglist@gmail.com
password: !qQuee5tMeedD1car3!


addressed used:

Soon Lee Street 3 
62 Singapore - Jurong West 
Singapore - Singapore
627607








<!--
   ____  _____ ______     _______ ____
  / ___|| ____|  _ \ \   / / ____|  _ \
  \___ \|  _| | |_) \ \ / /|  _| | |_) |
   ___) | |___|  _ < \ V / | |___|  _ <
  |____/|_____|_| \_\ \_/  |_____|_| \_\

-->


url: https://manage.hostsg.com/
// username: questmedicare                      // doesn't work, username must be an email address.
// password: Q7bF2rCP


jeremy.poon@hrquest.jobs
questmedicare@hrquest.jobs



Temporary FTP Hostname: questmedicare.com.customer.hostsg.com


ftp.questmedicare.com

Username: questmedicare
Password: Q7bF2rCP



<!--
   _____ ___  _   _ _____ ____
  |  ___/ _ \| \ | |_   _/ ___|
  | |_ | | | |  \| | | | \___ \
  |  _|| |_| | |\  | | |  ___) |
  |_|   \___/|_| \_| |_| |____/

-->





<script src="https://use.typekit.net/xwq7zmi.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>







