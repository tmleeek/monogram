Quest Medicare website copy

Tagline: Your Partners In Better Health and Vitality

ABOUT US
About Quest Medicare
Quest Medicare is an international medical concierge and facilitation company headquartered in Singapore. We have the necessary experience and expertise to be your preferred facilitator for healthcare needs, partnering you every step of the way in the journey to regaining your health and vitality. 

We understand the stress and confusion you can face when exploring medical treatment overseas. That’s why we provide a comprehensive suite of solutions from initital research information to aftercare support services, giving you peace of mind and allowing you to enjoy an stress-free trip.
   
Why Quest Medicare?

We have years of experience in the medical tourism industry, helping our customers achieve safe and effective treatment overseas.
We work primarily with JCI accredited hospitals and clinics, ensuring the best level of care possible for our patients.
The advantages of engaging us in your medical travel needs include:
- Cost effective medical treatment 
- Transparent fee structure 
- Pro-active and direct communication with your doctor before your travel
- A network of top specialists in their fields
- World class medical facilities
- Expedited waiting time
- Personalized packages and personal after-care services
- Full spectrum of travel facilitation, including visas and sightseeing
Corporate Social Responsibility
As part of our mission to give back to community and society, we will implement a series of CSR initiatives that will engage our diverse team and advance patient well-being. We will seek to enhance and protect the environment, and maximise social good in our communities.
Corporate Governance
(recommended to be part of ethics and values)

Ethics & Values 
We intend to uphold high standards of professionalism and corporate governance, with honesty and transparency our core values in all our interactions with customers and stakeholders.
Our patients’ well-being will always come first, and it is our aim to provide a service that places as priority their safety and peace of mind.
We will diligently weed out unfair and corrupt practices in our business and professional dealings, always conducting ourselves in an ethical and lawful manner.
Mission
We will partner with our patients, their loved ones and our healthcare providers to achieve optimal patient outcomes through:

a. empowering them with informed healthcare choices
b. supporting their autonomy in decision-making
c. providing quality care in world-class facilities with trusted partners.
d. practising constant care, respect and empathy for those entrusted to our care
e. maintaining the dignity, privacy and individuality of our patients

SERVICES
Quest Medicare provides a full suite of medical concierge services across a range of medical treatments. We have a particularly strong interest in diabetes treatment, tackling one of the world’s fastest growing health afflictions.
1. Medical Concierge
We understand the complexities of travelling to a foreign country to seek medical treatment. The cultural and language barriers can lead to much stress and anxiety, especially if the treatment requires a lenghty stay.
At Quest Medicare, our approach is centred around 3 main tenets:
a. Personalised solutions unique to each individual’s needs
b. World-class network of medical practitioners and facilities across the region
c. Comprehensive and personal services every step of the way, with the utmost confidentality
In short, we provide you with the information, support and resources to achieve your health goals in the most comfortable and cost effective manner.
Our comprehensive medical concierge services include:
End-to-end travel facilitation, including flights and accommodation
Airport pickup and transportation
Passport & visa processing
Translation services
Sightseeing
Round the clock support
After-care and recovery arrangements
Post-treatment follow up
2. Diabetes Treatment
Diabetes has been described as a ‘silent killer’ and it is no exagerration to say that it is today one of the biggest health problems around the world, and in particular, in Asia. Statistics show that more than 400 million people worldwide are living with diabetes, especially Type-2 diabetes, which is primarily caused by changing lifestyles, urbanisation and unhealthy diets.
The disease is particularly rampant in China, with about 10% of the population afflicted with mainly Type-2 diabetes. Already there are clear signs that the healthcare infrastructure in the country cannot support such a large number of cases. Diagnosis and treatment can be slow, leading to even more health complications.
Quest Medicare works with an established network of hospitals and clinics in diabetes treatment. In particular, we specialise in surgical intervention for obesity, also referred to as bariatric surgery.
Surgery for Diabetes & Weight Loss
Bariatric surgery is known to have profound effects on diabetes, helping people who suffer from obesity to regain control over their lives and their health. It effects weight loss by modifying gastro-intestinal anatomy, allowing the patient to feel full after eating small portions of food.
The International Diabetes Federation (IDF) in 2011 released a position statement recommending bariatric surgery as one of the therapeutic options for Type-2 diabetes control. Bariatric surgery, from the Greek “baros” meaning “weight”, is synonymous with weight loss surgery. Metabolic surgery, as a broader specialty, encompasses bariatric surgery, and it better reflects the aims and mechanisms of surgery with the primary intent to treat Type-2 diabetes - “diabetes surgery”. The idea derived not only from the remarkable clinical effects of bariatric surgery on diabetes, but also from the recognition that the gastrointestinal tract is a major player in the regulation of glucose homeostasis.  This finding led the industry to call for a new broad specialty, called gastrointestinal metabolic surgery, to be defined, encompassing the traditional use of bariatric surgery for weight loss as well as for the treatment of metabolic disorders.
Our specialists offer 4 minimally invasive techniques, tailored to remedy this problem including: gastric bypass, Laparoscopic adjustable gastric banding, Laparoscopic Roux-en-Y gastric bypass, Laparoscopic sleeve gastrectomy (LSG), and Gastric balloon.
Laparoscopic adjustable gastric banding (LAGB)
LAGB is a restrictive procedure used as a solution for morbid obesity. An adjustable silicone band is placed around the upper part of the stomach to reduce the size of the stomach so that a person feels full faster, thus eating less and ultimately losing weight. The pouch and the outlet should be small enough to restrict intake adequately yet not too small to cause obstruction. The band is deemed adjustable because a port implanted under the skin allows for fine adjustment of the outlet diameter.
Laparoscopic sleeve gastrectomy (LSG)
This is a restrictive procedure where the stomach is tubularised and the excess part is removed. About 75% of the stomach can be removed in this way. Although this is a relatively new procedure, early results show that weight loss after LSG is comparable to LAGB. Unlike the LAGB, this procedure is performed once only and no adjustments are required thereafter.
Laparoscopic Roux-en-Y gastric bypass (LRYGB)
This is the most complex bariatric surgery available at SGH. Utilizing 6 trocars ranging from 5 to 12mm, a small gastric pouch is first created and then a bypass to the small intestine (jejunum) is performed. LRYGB effects weight loss in 2 ways. It reduces caloric intake and shunts food into the mid-jejunum, thus altering the mechanism of digestion. Evidence from large cohort studies and meta-analyses show that bypass procedures have a profound effect on gastro-intestinal physiology and are remarkably effective in correcting metabolic disorders such as type II diabetes mellitus and hyperlipidaemia.
3. Other Medical Treatments
COSMETIC SURGERY FACILITATION

Cosmetic Surgery is a discipline of medicine which is focused on enhancing appearance through surgical and medical techniques. Cosmetic surgery can be performed on all areas of the head, neck and body. Special skill and knowledge are essential and specialists in cosmetic surgery are competent in the anatomy, physiology, pathology and basic sciences.
Quest Medicare partners with renowned hospitals and clinics throughout Singapore, South Korea, Thailand and India for a wide range of cosmetic surgeries. We are affiliated with hospitals that are approved by Joint Commission International (JCI), and our dedicated and professional facilitators will guide you every step of the way from initial consultations to booking treatment and post-surgery follow up.
 What types of Cosmetic Surgery do we provide?
- Double Eyelid
- Ptosis Correction (Widening of Drooping Upper Eyelip)
- Epicanthoplasty (Elongate/Widening of eye horizontally)
- Lower Eyelip (Eyebag removal, bulging fat/excess skin removal)
- Zygoma Reduction (Cheekbone Reduction)
- Mandible Angle Resection (Square Jaw) 
- Chin Reduction
- Facial Fat Injection - Face Line Contouring
- Nose Augmentation / Rhinoplasty
- Liposuction
- Abdominoplasty (Tummy Tuck)
- Body Fat Grafting (Buttocks)
- Breast Augmentation
- Breast Lift (Mastopexy)
- Breast Reconstruction  
- Botox Injections

DENTISTRY 
Each year, millions of people travel to lower-cost destinations for dental treatment. The cost of dental care in the West is usually many times that in Asian countries. 
Quest Medicare partners with leading hospitals and specialists for quality dental care at affordable rates. We are affiliated with hospitals that are approved by the Joint Commission International (JCI). 
The types of dental treatment we provide include:
- Dental bonding
- Dental bridges and caps
- Dental crowns
- Dental fillings
- Dental implants
- Dentures
- Teeth whitening
- Tooth contouring and reshaping
- Composite and porcelain tooth veneers
- Dental scanning - Intra mouth
- Surgical intervention under general anaesthesia
- Ceramic caps without gold under microscopic control
- Vertical and horizontal bone grafting
- Gum grafting
- Palatal orthodontics
- Maxillary surgery
- Over denture
- Combined prostheses with milling


GASTROENTEROLOGY
Gut, Liver and Advanced Laparoscopic Surgery
Quest Medicare provides one-stop services for the assessment and treatment of a comprehensive spectrum of digestive diseases. These include:
Esophageal Disorders

- Swallowing problems, structure, achalasia
- Endoscopic balloon dilation, cardiomyotomy
- Heartburn, gastroesophageal reflux
- Esophageal varices, transection surgery
- Esophageal Cancer, radical esphagectomy
- Thoracoscopic and keyhole esophageal surgery
 Stomach Disorders

- Epigastric pain, gyspepsia, gastritis, Helicobactor pylori
- Peptic ulcers, ulcer surgery, laparoscopic vagotomy,
- Vomiting, gastric outlet obstruction, laparoscopic bypass
- Gastric polyps and benign tumours, stomach cancer
- Radical gastrectomy and lymphadenectomy
- Laparoscopic gastric surgery, gastrectomy
- Laparoscopic endoluminal intragastric surgery
- Gastric foreign bodies, bezoars, stomach perforation
 Abdominal Surgery

- Acute abdmen, diagnostic laparoscopy
- Acute appendicitis, laparoscopic appendicectomy
- Retroperitoneal tumours, sarcomas, cancers
- Blunt and acute abdominal trauma
- Small bowel tumours, intestinal obstruction
- Short gut syndrome, small bowel failure
 Liver Surgery

- Abnormal liver function, jaundice, liver failure
- Liver cirrhosis, portal hypertension portal-systemic shunt surgery
- Liver cysts, polycystic liver disease, laparoscopic deroofing
- Benign and malignant liver tumours, metastatic liver cancers
- Transarterial chemoembolization, percutaneous ablation
- Liver resection, hepatectomy
- Laparoscopic liver surgery including resection
- Liver transplantation assessment for end-stage liver disease
Gallbladder and Biliary Surgery

- Gallbladder and bile duct stones, acute and chronic cholecystitis
- Lapascopic cholecystectomy, laparoscopic bile duct exploration
- Needlescopic cholecystectomy, single incision laparoscopic cholecystectomy
- Benign and malignant biliary stricture surgery
- Choledochal cyst surgery
 Pancreatic Disorders

- Acute and chronic pancreatits
- Pancreatic Stones
- Pancreatic cysts, cystic tumours, benign tumours
- Pancreatic cancers
- Radical pancreatectomy, laparoscopic pancreatectomy

4. Medi-Spa

The Medi-Spa concept has become very popular over the last decade or so, filling a demand for non-surgical health and beauty treatments in resort settings.

Our Medi-Spa partners in India and South Korea offer a wide range of options in beautiful natural environments that promote well-being inside and out. For example, in South Korea, our partner markets itself as a “natural clinic surrounded by mountain ranges and water”, offering programmes throughout the year. Visitors can also enjoy healing foods prepared with fresh local produce that heal both mind and body.

Some of the services you can expect at our Medi-Spa partners include skin and beauty treatments, detox, anti-ageing programmes, preventive and curative medical care, and traditional treatments like ayurveda.

Perfect for an intimate getaway or corporate retreats, Medi-Spas provide a relaxing escape from the stresses of everyday life, ensuring you won’t get the feeling of needing a holiday to recover from a holiday!


DESTINATIONS

Quest Medicare works with a number of world-class medical facilities in Singapore, Thailand, South Korea and India - these destinations account for about 90% of all medical tourism in Asia.

Each country has unique strengths in different medical specialities at different price points, and once we understand your needs and requirements, we will match you with the best medical provider.

Singapore

Singapore is a renowned healthcare service hub in the Asia-Pacific region, with top rankings by the World Health Organisation for healthcare infrastructure.

The popularity of Singapore as a medical tourism destination is due to a robust and integrated healthcare system, advanced medical research and collaboration, top-notch medical education and state-of-the-art. 

The country specializes in every major specialty and subspecialty, including oncology, neurology, gynaecology, cardiovascular, orthopaedics, cosmetics, endocrinology and sports medicine. Over the last decade or so, Singapore has become synonymous with “medical tourism in safe hands”.

Key Strengths of Singapore as a medical tourism destination include:

1. Location & Receptiveness 
Singapore is strategically located and connected to almost every city in the world. The country is also multicultural and multiracial and accommodates people from everywhere, making it the top ranked medical hub in the region.

2. Comprehensive Choices
Singapore offers a comprehensive range of choices for different areas of specialty and varying needs of patients. International clients can choose from different types of health treatments from Western medicine, Traditional Chinese Medicine and alternatative medical treatment.

3. Safe & Trustworthy Reputation
All Singapore hospitals are strictly regulated by the Ministry of Health, and they have almost a quarter of all JCI-accredited facilities in Asia. Singapore’s blood supply also ranks among the safest in the world.

Singapore is also very safe for tourists and there is no danger of any riots, social or government unrest, allowing patients to recover with peace of mind.

4. Clinical Research & Biomedical links
Singapore offers patients highly specialized and cutting edge treatments such as transplant and stem cell therapy.

There has been substantial investment in the country’s clinical research and biomedical industries, attracting major investments from pharmaceutical companies like GlaxoSmithKline, Pfizer, Novartis, Lonza and Roche. 

5. Affordability
While medical costs in Singapore are generally more expensive than in most Asian countries, it is still affordable compared to other developed countries such as the US or UK, while offering a high quality of healthcare options.


Thailand

Thailand is well-known as one of the most cost effective medical tourism destinations in Asia. When the Thai baht crashed during the 1997 Asian Financial crisis, business leaders capitalized on the favourable exchange rates to focus on medical tourism to attract international tourists and patients from nearby countries. 

Today, over half a million of tourists head to Thailand for medical treatment annually, in turn fuelling the rapid build up of excellent infrastructure and facilities. Specialties offered in Thailand include cosmetic surgery, orthopaedics, cardiology, IVF/reproductive medicine, spine surgery, and dentistry. Its famous vacation spots have also contributed substantially to those who seek to incorporate a recuperative vacation. The Thais are also known for their exceptional hospitality, and this service and graciousness extends deep into the clinical experience as well.
 
Key Strengths of Thailand as a medical tourism destination include:

1. Value for money
Thailand is renowned as one of the best value-for-money medical destinations globally, providing affordable world-class medical treatment for both elective and non-elective procedures. Its favourable exchange rate makes it about 40-60% cheaper compared to US and UK, and 30-40% cheaper than Singapore, for similar procedures.

2. Bumrungrad & Dusit Medical Group
Thailand’s main medical calling card is Bumrungrad International Hospital, the first JCI-accredited hospital in Asia. It has more than 900 consulting doctors representing every specialty and subspecialty and with excellent facilities to match. 

Equally famous is the Dusit Medical Group which owns and operates a large network of hospitals throughout Thailand, such as Bangkok International Hospital, Bangkok Hospital Phuket, Bangkok General Hospital, and Samitivej Sukhumvit Hospital. Together, they have contributed significantly to Thailand’s reputation as a world class medical tourism destination.

3. Vacation Haven
Thailand has always been among the top vacation choices for tourists globally. From warm hospitality to world class beach resorts to great food, Thailand has it all. This makes Thailand a prime destination for medical tourists seeking quality health treatment with relaxing recuperative vacation time.

4. Comprehensive Services
Thailand’s hospitals offer a complete range of medical procedures, from cosmetic surgery to IVF/reproductive medicine to dentistry. Hospitals in Thailand are also very popular with those who travel from neighbouring Asian countries to seek treatment. Bangkok Hospital, which specifically caters to medical tourists, has an entire Japanese wing, while Phyathai Hospitals Group has translators for 22 languages, including Swedish, Khmer and Flemish, as well as a team of English-speaking staff. 


South Korea

South Korea’s reputation as a medical tourism destination has risen rapidly over the past decade. It now boasts of more than 25 international hospitals, with 32 South Korean hospitals and clinics JCI-accredited, more than any other nation in North Asia. 

While South Korea’s healthcare is synonymous with cosmetic surgery, it boasts a wide range of specialties and procedures, notably spinal disorders and cancer. Korean specialty hospital and clinics are also famous for embracing established non-Western strategies, such as herbal treatments and acupuncture, integrated with allopathic care. 

Preventive care is popular as well, with many patients seeking inexpensive comprehensive screenings that include dental, audio, vision and MRIs. The doctors in South Korea are revered for their remarkable motor skills, effectively resulting in shorter surgery and treatment times, which appeal to many short-term visiting patients.

Key Strengths of South Korea as a Medical Tourism Destination: (note: needs re-writing)

1.   Technology
South Korea is one of the world’s most technologically and scientifically advanced countries, and that is apparent in its healthcare infrastructure and faciltiies. Its advanced physical screening examinations offer a high level of accuracy, and up to 60 types of examinations are available and test results are given one to two days later. Korea’s use of da Vinci robot surgery is also highly precise and ensures speedy recovery times because incisions are minimally invasive. 

Korean medical centers provide proton therapy, which is highly effective in the treatment of solid tumors, and TomoTherapy, which delivers pinpoint radiation to cancerous tissue, leaving healthy tissue virtually untouched. Proton therapy and TomoTherapy are exceptionally accurate and have fewer side effects than conventional radiation treatments. 

2. King of Cosmetics
The South Korean entertainment scene has been highly successfully in appealing to the global market, and with it, the rise of demand for cosmetic surgery. South Korea is the mecca of cosmetic surgery, and has one of the world’s highest number of plastic surgeons per capita. The doctors here are renowned for being the most effective plastic surgeons globally, with procedures often completed in a substantially shorter treatment time with very low complication rates. Just about every type of cosmetic procedure can be found and done in South Korea. 

3. Traditional + Modern
Korean hospitals and clinics offer alternative approaches to Western procedures, such as herbal treatments and acupuncture, integrated with allopathic care. Doctors specializing in traditional oriental medicine provide various non-surgical treatments as options. 

Boasting 2000 years of history, Korean traditional medicine targets the root of the illness, relying on the body’s own strengths to heal and prevent the illness from recurring. Visits to homeopathic clinics include individual assessments according to body constitution, where patients have the option of choosing traditional medicine together with modern advanced technological treatments – truly the best of both East and West. 

4. Holiday Paradise
In South Korea, tourists can experience the perfect co-existence of tradition and modern. On top of fantastic shopping, food and nightlife, you can recuperate post-treatment surrounded by mountains, rivers and oceans, or you can enjoy celebrity concerts or visit famous filming locations.

5. Climate
While South and South East Asian countries are stuck with a regular all-seasonal tropical climate, medical travellers who react adversely to the heat and humidity of those countries will find South Korea’s northern mountainous climate more to their liking. The cooling climate also appeals to tourists from tropical countries who seek a cooler refreshing climate, especially helpful after surgical procedures. 


India

As a medical tourism destination, India has become synonymous with cost-effective treatments for any type of medical condition. With a surplus of well-trained medical practitioners and low infrastructure costs, India is now the world’s value leader for the international cost-conscious medical traveller. 

While Singapore and Thailand are known for recruiting top-of-the-line specialists from other countries, India produces top home-grown physicians and surgeons. Cardiology has become a specialty in India, with facilities such as Fortis Wockhardt and Apollo fast becoming the calling cards for international patients.

Key Strengths of India as a Medical Tourism Destination: 

1.   Cost Effective
Healthcare in India is among the most cost-effective in the world with private hospitals offering treatment at a fraction of the price of those in more affluent nations. Patients willing to explore India’s medical facilities can easily save up to 80% on high-acuity procedures such as heart treatment due to the abundance of quality professionals and low infrastructure costs. 

2. Alternative Therapies
India is famous for its ancient alternative therapies such as Ayurveda, Yoga, Meditation, and Therapeutic Massage. Aside from its modern, technology-driven procedures, patients are able to explore various forms of alternative treatments, with ample facilities offering such options for international patients. 

3. International Collaborations
The ascendancy of India’s medical tourism indistry in the past decade has led to an influx of international pharmaceutical companies and foreign investors in numerous multi-specialty hospitals. These state-of-the art facilities and research centres have created an ideal environment for specialists to tackle almost all forms of ailments and diseases, thus providing international patients with more options for treatment. 

4. Abundance of talent
India produces a large number of doctors and hospital support staff. A high percentage of these top notch specialists posses overseas experience and some are leading figures in their fields; in fact, a substantial percentage of specialists in the US and Middle East are of Indian descent. 

5. Technology
India is a leading IT country, with healthcare services and facilities boasting world class technology. Patients can be rest assured that the private hospitals and surgery clinics in India are at the forefront of medical technology and are equipped with modern state-of-the-art technology and highly skilled medical personnel. 




















PROCESS

We adopt a clear and transparent process from enquiry to recovery, so that you have peace of mind in knowing exactly what you can expect.
1. Contact Us
Be it any question or clarifications you may require, we're here for you. Get in touch with us to begin your journey towards wellness and vitality.
2. Initial Assessment
We will assess your requirements and ask you for clarification if required. We may also ask for your medical records or history.
3. Medical Assessment
We will facilitate your medical records to a specialist in the destination of your choice so that they may assess your case and recommend the right treatment for you.
4. Meeting Your Specialist
We understand most patients would prefer to have an intial discussion with the doctor prior to departure. We can facilitate this with our partnering Specialists and this may be arranged via email, phone, and/or Skype.
5. Preparing Your Trip
We will take care of all the details and help you plan and prepare for everything you and your companion will need for the entirety of your trip. An information pack will be issued to you.
6. Arrival at Destination
Our friendly staff will be at the airport to pick you up on arrival and you'll be chauffeured to your accommodation or the medical centre, dependent on the tailored itinerary.
7. Treatment
Attend a health screening and consultation meeting with the doctor, surgeon or specialist looking after your treatment. We can arrange for you to be picked up from your hotel if you are not staying at the medical centre. Your treatment will be carried subsequently upon advice following the consultation. Translation services can be provided to help you communicate with your doctor.

8. Recuperation
Recuperate in the medical centre or at your hotel of choice. Depending on the treatment and advice from your doctor, we can also arrange sightseeing tours for you after your treatment.
9. Returning Home and Follow-Up Care
You’ll be well rested by the time you're ready to check out and go home, but that doesn't mean that your return trip should add any unwanted stress. We'll handle your transportation and your return travel plans, as well as any necessary follow-up care, be it another trip or a consult with your local doctor.

FAQS 
How much will I need to spend?
This depends on several factors, like the destination of treatment and the complexity of the procedure. In general, we can accommodate different budgets and expectations, and if need be, we can also advise you on medical insurance matters.
How long will I need to spend abroad?
Typically 1-2 days for simple procedures and at least a week for more complicated treatments, including recuperation.
Will I stay in a hotel or a hospital?
You may spend more time at a hotel than at a hospital during your medical trip. Depending on your procedure, oftentimes you will only stay a night or two in the hospital and then spend the rest of the time at a hotel recuperating and/ or engaging in physical rehabilitation. We can help you choose a hotel that has experience with medical tourists and that understands your needs and expectations.
Will I be travelling alone?
Your companion could make or break your medical trip. Having the physical and moral support of a companion is one of the most important ingredients of a successful medical trip, particularly during the recovery process. However, not everyone is ideally suited to being a medical travel companion. Choose your companion wisely. Right now it’s all about you. Your companion must be willing to put your needs ahead of his or her own and assist you during the recovery process. This does not mean they cannot have some leisure time to enjoy the local culture and attractions, but they should understand that their primary purpose is to provide support.

What is JCI Accreditation?
Founded in 1994, Joint Commission International (JCI) is the world’s leader in health care accreditation and the author and evaluator of the most rigorous international standards in quality and patient safety.
JCI works to improve patient safety and quality of health care in the international community by offering education, publications, advisory services, and international accreditation and certification. In more than 100 countries, JCI partners with hospitals, clinics, and academic medical centres; health systems and agencies; government ministries; academia; and international advocates to promote rigorous standards of care and to provide solutions for achieving peak performance.
Accreditation is a long-term process that demands commitment. Each hospital and health care organization that applies for JCI accreditation takes about two years to prepare. There is a great deal of preparatory work leading up to a survey and then subsequent performance and improvement work is done to ensure those accreditation standards are maintained. Organizations that achieve and maintain JCI accreditation are dedicated to providing their patients the best level of care possible.
There are 823 JCI-accredited hospitals around the world. This figure does not include ambulatory clinics. Joint Commission is an independent not-for-profit organization that evaluates and accredits more than 15,000 healthcare organizations in the United States. Its international arm (Joint Commission International) has been accrediting hospitals outside the U.S. since the late 90’s. JCI accreditation is one of the main criteria patients use to ensure they are traveling to a hospital with high standards of patient care. 1.6 million U.S. patients traveling abroad for care. 


