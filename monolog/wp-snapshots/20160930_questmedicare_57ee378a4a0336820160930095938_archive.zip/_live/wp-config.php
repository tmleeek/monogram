<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'quest_wp');

/** MySQL database username */
define('DB_USER', 'quest_wp_user');

/** MySQL database password */
define('DB_PASSWORD', 'q8ues7_user!@');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'E1a:etELq&;~ m(rV!A0J,$1tz`< 2)I~UK]BPz,JC6*4^#SuRyx}Q;w-J5&X65p');
define('SECURE_AUTH_KEY',  'qpO#1Dyf,5x0#S~@a,NhGyo}fKp;b~jB,^d?J?)NbJzdx:G1#oV:nzW.3]H@q=j!');
define('LOGGED_IN_KEY',    'iOTN0ZS{y0k`3k{xo9)+al>u~Ble<rAv?>%E%RX48qC8T[JdvB.-`xQ7I^mq8ylW');
define('NONCE_KEY',        '^%;qv7`QrkXA|-Q5d)E?bQ(yN+Fc|W!FR8c+/tZ oT|?xWqGf[/Ef&CX21dKD|nM');
define('AUTH_SALT',        'cNjn3zxc<N5Dk7{vtIUNA4B<-fzPPyW|cLV%]$>(HEMiHdEj4fG2I?+g1eKst=w:');
define('SECURE_AUTH_SALT', '%7r;[?A1-}w5a:v79uWqWg[0-@g$&:{DUCdcR?2tM7#cZiQ>@R6Nf*zoNMv4P<~~');
define('LOGGED_IN_SALT',   'MJq^K(b3Yw57KjMrlTimt9:et$AUyYBN<p^GTn(Y|YOtv37#,i?}sd=%u)*-Zgo|');
define('NONCE_SALT',       'e10n<q.AJ^,F9;:,,G^gu,EI?CHNX}4jTK4MSfu[9fzf+V.@$~(&!YwsaK@u&Q#K');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
